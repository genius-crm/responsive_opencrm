<?php
/* +********************************************************************************
 * Terms & Conditions are placed on the: http://www.greenbitweb.com
 * *******************************************************************************
 *  Module				: Banche
 *  Author				: Matteo Barnaozni 
 *  Help/Email				: info@greenbitweb.com
 *  Website				: www.greenbitweb.com
 * *******************************************************************************+ */
$languageStrings = array(
	// Basic Strings
	'SINGLE_Ddt'     			=> 'DDT'         		    		, 
	'LBL_ADD_RECORD'            		=> 'Aggiungi DDT'		   		, 
	'LBL_RECORDS_LIST'             		=> 'Lista DDT'   		    		, 
	'All'		     			=> 'Tutti i'					, 
	'Ddt'		     			=> 'DDT'					, 
	'ddt No'	     			=> 'Numero DDT'					, 
	'LBL_DDT_INFORMATION'   		=> 'Informazioni DDT'				, 

);
$jsLanguageStrings = array(
);
