<?php
/* +********************************************************************************
 * Terms & Conditions are placed on the: http://www.greenbitweb.com
 * *******************************************************************************
 *  Module				: Banche
 *  Author				: Matteo Barnaozni 
 *  Help/Email				: info@greenbitweb.com
 *  Website				: www.greenbitweb.com
 * *******************************************************************************+ */
$languageStrings = array(
	// Basic Strings
	'SINGLE_Banche'                => 'Banca'                       , 
	'LBL_ADD_RECORD'               => 'Aggiungi banca'              , 
	'LBL_RECORDS_LIST'             => 'Lista banche'                , 
	'LBL_BANCHE_INFORMATION'       => 'Dettagli banca'              , 
	'banca_no'                     => 'Codice banca'                , 	
	'Nomebanca'                    => 'Nome banca'                , 	
);
$jsLanguageStrings = array(
);
