<?php
/* +********************************************************************************
 * Terms & Conditions are placed on the: http://www.greenbitweb.com
 * *******************************************************************************
 *  Module				: Banche
 *  Author				: Matteo Barnaozni 
 *  Help/Email				: info@greenbitweb.com
 *  Website				: www.greenbitweb.com
 * *******************************************************************************+ */
$languageStrings = array(
	// Basic Strings
	'SINGLE_Modalitapagamento'     		=> 'Modalità di pagamento'             		, 
	'LBL_ADD_RECORD'            		=> 'Aggiungi modalità di pagamento'   		, 
	'LBL_RECORDS_LIST'             		=> 'Lista modalità di pagamento'    		, 
	'pagamento_no'                     	=> 'Codice modalità di pagamento'		, 	
	'Modalitapagamento'                    	=> 'Modalità di pagamento'     			, 	
	'LBL_MODALITA_PAGAMENTO'                => 'Dettagli modalità di pagamento' 		, 	
	'LBL_MODALITAPAGAMENTO_INFORMATION'     => 'Informazioni modalità di pagamento' 	, 
	'LBL_ATTIVA'     			=> 'Modalità attiva'		 		, 
	'All'		     			=> 'Tutte le'					, 
);
$jsLanguageStrings = array(
);
